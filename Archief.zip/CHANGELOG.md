# BookStack Changelog

## [Initial Version] - 2024-04-26