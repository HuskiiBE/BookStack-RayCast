/// <reference types="@raycast/api">

/* 🚧 🚧 🚧
 * This file is auto-generated from the extension's manifest.
 * Do not modify manually. Instead, update the `package.json` file.
 * 🚧 🚧 🚧 */

/* eslint-disable @typescript-eslint/ban-types */

type ExtensionPreferences = {
  /** BookStack Base URL - Enter your BookStack base URL here */
  "baseUrl": string,
  /** BookStack API Token ID - Enter your BookStack API token ID here */
  "tokenId": string,
  /** BookStack API Token Secret - Enter your BookStack API token secret here */
  "tokenSecret": string
}

/** Preferences accessible in all the extension's commands */
declare type Preferences = ExtensionPreferences

declare namespace Preferences {
  /** Preferences accessible in the `search-command` command */
  export type SearchCommand = ExtensionPreferences & {}
  /** Preferences accessible in the `show-all-books` command */
  export type ShowAllBooks = ExtensionPreferences & {}
  /** Preferences accessible in the `show-all-shelves` command */
  export type ShowAllShelves = ExtensionPreferences & {}
}

declare namespace Arguments {
  /** Arguments passed to the `search-command` command */
  export type SearchCommand = {}
  /** Arguments passed to the `show-all-books` command */
  export type ShowAllBooks = {}
  /** Arguments passed to the `show-all-shelves` command */
  export type ShowAllShelves = {}
}

